﻿' Program Name: Vacation Distance Calculator
' Author:       Justin Nguyen
' Date:         October 27th, 2015
' Purpose:      The Vacation Distance program enters the days, miles, and hours
'               travled during trip. It displays total distance

Option Strict On
Public Class frmVacationDistanceCalculator



    Private Sub btnDistance_Click(sender As Object, e As EventArgs) Handles btnDistance.Click
        'The btnDistance button accepts and displays total distance
        'traveled based on hours, days, and speed

        'Declare Variables
        Dim intDays As Integer
        Dim decSpeed As Decimal
        Dim strHours As String
        Dim decHours As Decimal
        Dim decDistance As Decimal = 0D
        Dim strInputMessage As String = "Enter amount of hours you plan to drive for day "
        Dim strInputHeading As String = "Hours Driven for the Day"
        Dim strNormalMessgae As String = "Enter amount of hours you plan to drive for day "
        Dim strNonNumericError As String = "Error-Enter a number for driving hours "
        Dim strNegativeError As String = "Error-Enter a positive number for driving hours "

        'Declare and Initialize loop variables
        Dim strCancelClicked As String = ""
        Dim intMaxNumberOfEntries As Integer
        If IsNumeric(txtDays.Text) Then
            intDays = Convert.ToInt32(txtDays.Text)
            If intDays > 0 Then
                intMaxNumberOfEntries = intDays
            Else
                MsgBox("Please enter a positive number for days.", , "Input Error")
                txtDays.Text = " "
                txtDays.Focus()
            End If
        Else
            MsgBox("Please enter a numeric value for days.", , "Input Error")
            txtDays.Text = " "
            txtDays.Focus()
        End If

        If IsNumeric(txtSpeed.Text) Then
            decSpeed = Convert.ToDecimal(txtSpeed.Text)
            If decSpeed <= 0 Then
                MsgBox("Please enter a positive number for speed", , "Input Error")
                txtSpeed.Text = " "
                txtSpeed.Focus()
            End If
        Else
            MsgBox("Please enter a numeric value for speed.", , "Input Error")
            txtSpeed.Text = " "
            txtSpeed.Focus()
        End If

        Dim intNumberOfEntries As Integer = 1

        'This loop allows the user to enter the weight loss of up to 8 team members. 
        'The loop terminates when the user has evetred 8 weight loss values or the user
        'taps or clicks the cancel button or the close button in the input box

        strHours = InputBox(strInputMessage & intNumberOfEntries, strInputHeading, " ")

        Do Until intNumberOfEntries > intMaxNumberOfEntries Or strHours = strCancelClicked
            If IsNumeric(strHours) Then
                decHours = Convert.ToDecimal(strHours)
                If decHours > 0 Then
                    decDistance = decHours * decSpeed + decDistance
                    intNumberOfEntries += 1
                    strInputMessage = strNormalMessgae
                Else
                    strInputMessage = strNegativeError
                End If
            Else
                strInputMessage = strNonNumericError
            End If

            If intNumberOfEntries <= intMaxNumberOfEntries Then
                strHours = InputBox(strInputMessage & intNumberOfEntries, strInputHeading, " ")
            End If
        Loop

        'Displays Total
        If intNumberOfEntries > 1 Then
            lblTotal.Visible = True
            lblTotal.Text = "The total distance traveled is " & decDistance.ToString("F1") & " miles"
        Else
            MsgBox("No hours value entered")
        End If

        'Disables the weight loss button
        btnDistance.Enabled = False
    End Sub

    Private Sub mnuClear_Click(sender As Object, e As EventArgs) Handles mnuClear.Click
        'The mnuClear clears the text box and hides 
        'the . It also enables 
        'the weight loss button

        lblTotal.Visible = False
        txtDays.Clear()
        txtSpeed.Clear()
        txtSpeed.Focus()
        btnDistance.Enabled = True
    End Sub

    Private Sub mnuExit_Click(sender As Object, e As EventArgs) Handles mnuExit.Click
        'The mnuExit click event closes the window and exits the application

        Close()
    End Sub
End Class
