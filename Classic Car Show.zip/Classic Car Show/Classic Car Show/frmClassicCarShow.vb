﻿' Program Name: Classic Car Show
' Author:       Justin Nguyen
' Date:         November 20, 2015
' Purpose:      The classic car show application calculates the total
'               value of cars in inventory, and displays the models
'               in the list box

Option Strict On

Public Class frmClassicCarShow
    'Class Level Variables
    Private _intSizeOfArray As Integer = 10
    Private _strCarModel(_intSizeOfArray) As String
    Private _intCarValue(_intSizeOfArray) As Integer
    Private intValueTotal As Integer

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        'This calculate button sorts the array by model year 
        'then fills the listbox object with the model and year
        Dim intFill As Integer
        Array.Sort(_strCarModel)
        MakeObjectsVisible()
        For intFill = 0 To (_strCarModel.Length - 1)
            lstInventoryList.Items.Add(_strCarModel(intFill))
        Next


        lblValueDisplay.Text = "Total Value of Cars " & intValueTotal.ToString("C")
        lblTotalDisplay.Text = "Total Cars in Show " & (_intSizeOfArray + 1).ToString()


    End Sub

    Private Sub frmClassicCarShow_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Initialize an instance of the streamreader object and declare variables
        Dim objReader As IO.StreamReader
        Dim strLocationAndNameOfFile As String = "\\psf\Home\Desktop\cars.txt"
        Dim intCount As Integer = 0
        Dim strFileError As String = "The file is not availible. Restart when the file is availible"

        'verify the file exists
        If IO.File.Exists(strLocationAndNameOfFile) Then
            objReader = IO.File.OpenText(strLocationAndNameOfFile)
            'Read the file line by line until the file is completed
            Do While objReader.Peek <> -1
                _strCarModel(intCount) = objReader.ReadLine()
                _intCarValue(intCount) = Convert.ToInt32(objReader.ReadLine())
                intValueTotal = _intCarValue(intCount) + intValueTotal
                intCount += 1
            Loop
            objReader.Close()
        Else
            MsgBox(strFileError, , "Error")
            Close()
        End If
    End Sub

    Private Sub MakeObjectsVisible()
        'This procedure displays the objects showing the results
        lblTotalDisplay.Visible = True
        lblValueDisplay.Visible = True
        lstInventoryList.Visible = True
        lblInventory.Visible = True
        lstInventoryList.Items.Clear()
    End Sub

    Private Sub ClearToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ClearToolStripMenuItem.Click
        'The mnuClear event clears and resets the form
        lblTotalDisplay.Visible = False
        lblValueDisplay.Visible = False
        lstInventoryList.Visible = False
        lblInventory.Visible = False
        lstInventoryList.Items.Clear()
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        'The mnuExit click event closes the application
        Application.Exit()
    End Sub
End Class
