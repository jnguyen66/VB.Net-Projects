﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmClassicCarShow
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmClassicCarShow))
        Me.lblHeading = New System.Windows.Forms.Label()
        Me.lblInsurance = New System.Windows.Forms.Label()
        Me.lblInventory = New System.Windows.Forms.Label()
        Me.lblTotalDisplay = New System.Windows.Forms.Label()
        Me.lblValueDisplay = New System.Windows.Forms.Label()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.picCar = New System.Windows.Forms.PictureBox()
        Me.lstInventoryList = New System.Windows.Forms.ListBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClearToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        CType(Me.picCar, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblHeading
        '
        Me.lblHeading.AutoSize = True
        Me.lblHeading.Font = New System.Drawing.Font("Modern No. 20", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHeading.ForeColor = System.Drawing.Color.Navy
        Me.lblHeading.Location = New System.Drawing.Point(18, 27)
        Me.lblHeading.Name = "lblHeading"
        Me.lblHeading.Size = New System.Drawing.Size(157, 21)
        Me.lblHeading.TabIndex = 0
        Me.lblHeading.Text = "Classic Car Show"
        '
        'lblInsurance
        '
        Me.lblInsurance.AutoSize = True
        Me.lblInsurance.Font = New System.Drawing.Font("Modern No. 20", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInsurance.ForeColor = System.Drawing.Color.Navy
        Me.lblInsurance.Location = New System.Drawing.Point(19, 53)
        Me.lblInsurance.Name = "lblInsurance"
        Me.lblInsurance.Size = New System.Drawing.Size(167, 17)
        Me.lblInsurance.TabIndex = 1
        Me.lblInsurance.Text = "Total Value for Insurance"
        '
        'lblInventory
        '
        Me.lblInventory.AutoSize = True
        Me.lblInventory.Font = New System.Drawing.Font("Modern No. 20", 14.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInventory.ForeColor = System.Drawing.Color.Navy
        Me.lblInventory.Location = New System.Drawing.Point(170, 109)
        Me.lblInventory.Name = "lblInventory"
        Me.lblInventory.Size = New System.Drawing.Size(174, 21)
        Me.lblInventory.TabIndex = 2
        Me.lblInventory.Text = "Classic Car Inventory"
        Me.lblInventory.Visible = False
        '
        'lblTotalDisplay
        '
        Me.lblTotalDisplay.AutoSize = True
        Me.lblTotalDisplay.Font = New System.Drawing.Font("Modern No. 20", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotalDisplay.ForeColor = System.Drawing.Color.Navy
        Me.lblTotalDisplay.Location = New System.Drawing.Point(14, 145)
        Me.lblTotalDisplay.Name = "lblTotalDisplay"
        Me.lblTotalDisplay.Size = New System.Drawing.Size(199, 21)
        Me.lblTotalDisplay.TabIndex = 3
        Me.lblTotalDisplay.Text = "Total Cars in show 11"
        Me.lblTotalDisplay.Visible = False
        '
        'lblValueDisplay
        '
        Me.lblValueDisplay.AutoSize = True
        Me.lblValueDisplay.Font = New System.Drawing.Font("Modern No. 20", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblValueDisplay.ForeColor = System.Drawing.Color.Navy
        Me.lblValueDisplay.Location = New System.Drawing.Point(289, 145)
        Me.lblValueDisplay.Name = "lblValueDisplay"
        Me.lblValueDisplay.Size = New System.Drawing.Size(310, 21)
        Me.lblValueDisplay.TabIndex = 4
        Me.lblValueDisplay.Text = "Total Value of Cars $XXX,XXXX"
        Me.lblValueDisplay.Visible = False
        '
        'btnCalculate
        '
        Me.btnCalculate.BackColor = System.Drawing.Color.Navy
        Me.btnCalculate.Font = New System.Drawing.Font("Modern No. 20", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCalculate.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnCalculate.Location = New System.Drawing.Point(369, 44)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(175, 34)
        Me.btnCalculate.TabIndex = 5
        Me.btnCalculate.Text = "Compute Inventory"
        Me.btnCalculate.UseVisualStyleBackColor = False
        '
        'picCar
        '
        Me.picCar.Image = CType(resources.GetObject("picCar.Image"), System.Drawing.Image)
        Me.picCar.Location = New System.Drawing.Point(274, 191)
        Me.picCar.Name = "picCar"
        Me.picCar.Size = New System.Drawing.Size(317, 264)
        Me.picCar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picCar.TabIndex = 6
        Me.picCar.TabStop = False
        '
        'lstInventoryList
        '
        Me.lstInventoryList.Font = New System.Drawing.Font("Modern No. 20", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstInventoryList.ForeColor = System.Drawing.Color.Navy
        Me.lstInventoryList.FormattingEnabled = True
        Me.lstInventoryList.ItemHeight = 21
        Me.lstInventoryList.Location = New System.Drawing.Point(8, 191)
        Me.lstInventoryList.Name = "lstInventoryList"
        Me.lstInventoryList.Size = New System.Drawing.Size(256, 256)
        Me.lstInventoryList.TabIndex = 7
        Me.lstInventoryList.Visible = False
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(603, 24)
        Me.MenuStrip1.TabIndex = 8
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ClearToolStripMenuItem, Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'ClearToolStripMenuItem
        '
        Me.ClearToolStripMenuItem.Name = "ClearToolStripMenuItem"
        Me.ClearToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ClearToolStripMenuItem.Text = "Clear"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'frmClassicCarShow
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(603, 463)
        Me.Controls.Add(Me.lstInventoryList)
        Me.Controls.Add(Me.picCar)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.lblValueDisplay)
        Me.Controls.Add(Me.lblTotalDisplay)
        Me.Controls.Add(Me.lblInventory)
        Me.Controls.Add(Me.lblInsurance)
        Me.Controls.Add(Me.lblHeading)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frmClassicCarShow"
        Me.Text = "Classic Car Show"
        CType(Me.picCar, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblHeading As System.Windows.Forms.Label
    Friend WithEvents lblInsurance As System.Windows.Forms.Label
    Friend WithEvents lblInventory As System.Windows.Forms.Label
    Friend WithEvents lblTotalDisplay As System.Windows.Forms.Label
    Friend WithEvents lblValueDisplay As System.Windows.Forms.Label
    Friend WithEvents btnCalculate As System.Windows.Forms.Button
    Friend WithEvents picCar As System.Windows.Forms.PictureBox
    Friend WithEvents lstInventoryList As System.Windows.Forms.ListBox
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ClearToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

End Class
