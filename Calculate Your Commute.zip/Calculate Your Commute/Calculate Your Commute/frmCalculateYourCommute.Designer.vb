﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCalculateYourCommute
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmCalculateYourCommute))
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.lblHeading = New System.Windows.Forms.Label()
        Me.cboTransportMethod = New System.Windows.Forms.ComboBox()
        Me.lblCost = New System.Windows.Forms.Label()
        Me.lblCostDisplay = New System.Windows.Forms.Label()
        Me.lblRoundTripFare = New System.Windows.Forms.Label()
        Me.txtRTFare = New System.Windows.Forms.TextBox()
        Me.lblDaysPerMonth = New System.Windows.Forms.Label()
        Me.txtDaysPerMonth = New System.Windows.Forms.TextBox()
        Me.lblMpg = New System.Windows.Forms.Label()
        Me.txtMpg = New System.Windows.Forms.TextBox()
        Me.lblCostPerGallon = New System.Windows.Forms.Label()
        Me.txtCostPerGallon = New System.Windows.Forms.TextBox()
        Me.lblMaintInsuranceCost = New System.Windows.Forms.Label()
        Me.txtInsMaint = New System.Windows.Forms.TextBox()
        Me.lblParkingCost = New System.Windows.Forms.Label()
        Me.txtParkingCost = New System.Windows.Forms.TextBox()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.lblDailyRTDistance = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtDailyRTDistance = New System.Windows.Forms.TextBox()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(-1, 290)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(558, 266)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'lblHeading
        '
        Me.lblHeading.AutoSize = True
        Me.lblHeading.Location = New System.Drawing.Point(12, 9)
        Me.lblHeading.Name = "lblHeading"
        Me.lblHeading.Size = New System.Drawing.Size(101, 13)
        Me.lblHeading.TabIndex = 1
        Me.lblHeading.Text = "Commute Calculator"
        '
        'cboTransportMethod
        '
        Me.cboTransportMethod.FormattingEnabled = True
        Me.cboTransportMethod.Items.AddRange(New Object() {"Car", "Train", "Bus"})
        Me.cboTransportMethod.Location = New System.Drawing.Point(12, 25)
        Me.cboTransportMethod.Name = "cboTransportMethod"
        Me.cboTransportMethod.Size = New System.Drawing.Size(201, 21)
        Me.cboTransportMethod.TabIndex = 2
        Me.cboTransportMethod.Text = "Select your method of transportation:"
        '
        'lblCost
        '
        Me.lblCost.AutoSize = True
        Me.lblCost.Location = New System.Drawing.Point(9, 260)
        Me.lblCost.Name = "lblCost"
        Me.lblCost.Size = New System.Drawing.Size(218, 13)
        Me.lblCost.TabIndex = 3
        Me.lblCost.Text = "Your cost of commuting to work for one year:"
        Me.lblCost.Visible = False
        '
        'lblCostDisplay
        '
        Me.lblCostDisplay.AutoSize = True
        Me.lblCostDisplay.Location = New System.Drawing.Point(308, 260)
        Me.lblCostDisplay.Name = "lblCostDisplay"
        Me.lblCostDisplay.Size = New System.Drawing.Size(46, 13)
        Me.lblCostDisplay.TabIndex = 4
        Me.lblCostDisplay.Text = "$888.88"
        Me.lblCostDisplay.Visible = False
        '
        'lblRoundTripFare
        '
        Me.lblRoundTripFare.AutoSize = True
        Me.lblRoundTripFare.Location = New System.Drawing.Point(275, 61)
        Me.lblRoundTripFare.Name = "lblRoundTripFare"
        Me.lblRoundTripFare.Size = New System.Drawing.Size(118, 13)
        Me.lblRoundTripFare.TabIndex = 5
        Me.lblRoundTripFare.Text = "Enter Round Trip Fare: "
        Me.lblRoundTripFare.Visible = False
        '
        'txtRTFare
        '
        Me.txtRTFare.Location = New System.Drawing.Point(428, 61)
        Me.txtRTFare.Name = "txtRTFare"
        Me.txtRTFare.Size = New System.Drawing.Size(63, 20)
        Me.txtRTFare.TabIndex = 6
        Me.txtRTFare.Visible = False
        '
        'lblDaysPerMonth
        '
        Me.lblDaysPerMonth.AutoSize = True
        Me.lblDaysPerMonth.Location = New System.Drawing.Point(12, 58)
        Me.lblDaysPerMonth.Name = "lblDaysPerMonth"
        Me.lblDaysPerMonth.Size = New System.Drawing.Size(155, 13)
        Me.lblDaysPerMonth.TabIndex = 7
        Me.lblDaysPerMonth.Text = "Enter Days Worked Per Month:"
        Me.lblDaysPerMonth.Visible = False
        '
        'txtDaysPerMonth
        '
        Me.txtDaysPerMonth.Location = New System.Drawing.Point(173, 58)
        Me.txtDaysPerMonth.Name = "txtDaysPerMonth"
        Me.txtDaysPerMonth.Size = New System.Drawing.Size(62, 20)
        Me.txtDaysPerMonth.TabIndex = 8
        Me.txtDaysPerMonth.Visible = False
        '
        'lblMpg
        '
        Me.lblMpg.AutoSize = True
        Me.lblMpg.Location = New System.Drawing.Point(12, 90)
        Me.lblMpg.Name = "lblMpg"
        Me.lblMpg.Size = New System.Drawing.Size(140, 13)
        Me.lblMpg.TabIndex = 9
        Me.lblMpg.Text = "Enter Car's Miles Per Gallon:"
        Me.lblMpg.Visible = False
        '
        'txtMpg
        '
        Me.txtMpg.Location = New System.Drawing.Point(173, 90)
        Me.txtMpg.Name = "txtMpg"
        Me.txtMpg.Size = New System.Drawing.Size(62, 20)
        Me.txtMpg.TabIndex = 10
        Me.txtMpg.Visible = False
        '
        'lblCostPerGallon
        '
        Me.lblCostPerGallon.AutoSize = True
        Me.lblCostPerGallon.Location = New System.Drawing.Point(275, 93)
        Me.lblCostPerGallon.Name = "lblCostPerGallon"
        Me.lblCostPerGallon.Size = New System.Drawing.Size(111, 13)
        Me.lblCostPerGallon.TabIndex = 11
        Me.lblCostPerGallon.Text = "Enter Cost Per Gallon:"
        Me.lblCostPerGallon.Visible = False
        '
        'txtCostPerGallon
        '
        Me.txtCostPerGallon.Location = New System.Drawing.Point(428, 88)
        Me.txtCostPerGallon.Name = "txtCostPerGallon"
        Me.txtCostPerGallon.Size = New System.Drawing.Size(63, 20)
        Me.txtCostPerGallon.TabIndex = 12
        Me.txtCostPerGallon.Visible = False
        '
        'lblMaintInsuranceCost
        '
        Me.lblMaintInsuranceCost.AutoSize = True
        Me.lblMaintInsuranceCost.Location = New System.Drawing.Point(12, 162)
        Me.lblMaintInsuranceCost.Name = "lblMaintInsuranceCost"
        Me.lblMaintInsuranceCost.Size = New System.Drawing.Size(229, 13)
        Me.lblMaintInsuranceCost.TabIndex = 13
        Me.lblMaintInsuranceCost.Text = "Enter Montly Maintenance and Insurance Cost:"
        Me.lblMaintInsuranceCost.Visible = False
        '
        'txtInsMaint
        '
        Me.txtInsMaint.Location = New System.Drawing.Point(298, 162)
        Me.txtInsMaint.Name = "txtInsMaint"
        Me.txtInsMaint.Size = New System.Drawing.Size(100, 20)
        Me.txtInsMaint.TabIndex = 14
        Me.txtInsMaint.Visible = False
        '
        'lblParkingCost
        '
        Me.lblParkingCost.AutoSize = True
        Me.lblParkingCost.Location = New System.Drawing.Point(275, 130)
        Me.lblParkingCost.Name = "lblParkingCost"
        Me.lblParkingCost.Size = New System.Drawing.Size(138, 13)
        Me.lblParkingCost.TabIndex = 15
        Me.lblParkingCost.Text = "Enter Monthly Parking Cost:"
        Me.lblParkingCost.Visible = False
        '
        'txtParkingCost
        '
        Me.txtParkingCost.Location = New System.Drawing.Point(439, 127)
        Me.txtParkingCost.Name = "txtParkingCost"
        Me.txtParkingCost.Size = New System.Drawing.Size(100, 20)
        Me.txtParkingCost.TabIndex = 16
        Me.txtParkingCost.Visible = False
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(217, 206)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(100, 24)
        Me.btnCalculate.TabIndex = 17
        Me.btnCalculate.Text = "Calculate Cost"
        Me.btnCalculate.UseVisualStyleBackColor = True
        Me.btnCalculate.Visible = False
        '
        'lblDailyRTDistance
        '
        Me.lblDailyRTDistance.AutoSize = True
        Me.lblDailyRTDistance.Location = New System.Drawing.Point(9, 127)
        Me.lblDailyRTDistance.Name = "lblDailyRTDistance"
        Me.lblDailyRTDistance.Size = New System.Drawing.Size(165, 13)
        Me.lblDailyRTDistance.TabIndex = 18
        Me.lblDailyRTDistance.Text = "Enter Daily Round Trip Distance: "
        Me.lblDailyRTDistance.Visible = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(23, 140)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(0, 13)
        Me.Label2.TabIndex = 19
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(57, 148)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(0, 13)
        Me.Label3.TabIndex = 20
        '
        'txtDailyRTDistance
        '
        Me.txtDailyRTDistance.Location = New System.Drawing.Point(176, 127)
        Me.txtDailyRTDistance.Name = "txtDailyRTDistance"
        Me.txtDailyRTDistance.Size = New System.Drawing.Size(65, 20)
        Me.txtDailyRTDistance.TabIndex = 21
        Me.txtDailyRTDistance.Visible = False
        '
        'frmCalculateYourCommute
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(556, 555)
        Me.Controls.Add(Me.txtDailyRTDistance)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lblDailyRTDistance)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.txtParkingCost)
        Me.Controls.Add(Me.lblParkingCost)
        Me.Controls.Add(Me.txtInsMaint)
        Me.Controls.Add(Me.lblMaintInsuranceCost)
        Me.Controls.Add(Me.txtCostPerGallon)
        Me.Controls.Add(Me.lblCostPerGallon)
        Me.Controls.Add(Me.txtMpg)
        Me.Controls.Add(Me.lblMpg)
        Me.Controls.Add(Me.txtDaysPerMonth)
        Me.Controls.Add(Me.lblDaysPerMonth)
        Me.Controls.Add(Me.txtRTFare)
        Me.Controls.Add(Me.lblRoundTripFare)
        Me.Controls.Add(Me.lblCostDisplay)
        Me.Controls.Add(Me.lblCost)
        Me.Controls.Add(Me.cboTransportMethod)
        Me.Controls.Add(Me.lblHeading)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "frmCalculateYourCommute"
        Me.Text = "Calculate Commute"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents lblHeading As System.Windows.Forms.Label
    Friend WithEvents cboTransportMethod As System.Windows.Forms.ComboBox
    Friend WithEvents lblCost As System.Windows.Forms.Label
    Friend WithEvents lblCostDisplay As System.Windows.Forms.Label
    Friend WithEvents lblRoundTripFare As System.Windows.Forms.Label
    Friend WithEvents txtRTFare As System.Windows.Forms.TextBox
    Friend WithEvents lblDaysPerMonth As System.Windows.Forms.Label
    Friend WithEvents txtDaysPerMonth As System.Windows.Forms.TextBox
    Friend WithEvents lblMpg As System.Windows.Forms.Label
    Friend WithEvents txtMpg As System.Windows.Forms.TextBox
    Friend WithEvents lblCostPerGallon As System.Windows.Forms.Label
    Friend WithEvents txtCostPerGallon As System.Windows.Forms.TextBox
    Friend WithEvents lblMaintInsuranceCost As System.Windows.Forms.Label
    Friend WithEvents txtInsMaint As System.Windows.Forms.TextBox
    Friend WithEvents lblParkingCost As System.Windows.Forms.Label
    Friend WithEvents txtParkingCost As System.Windows.Forms.TextBox
    Friend WithEvents btnCalculate As System.Windows.Forms.Button
    Friend WithEvents lblDailyRTDistance As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtDailyRTDistance As System.Windows.Forms.TextBox

End Class
