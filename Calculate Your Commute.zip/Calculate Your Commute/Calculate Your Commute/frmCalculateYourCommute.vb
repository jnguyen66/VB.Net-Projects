﻿' Program Name: Calculate Your Commute
' Author:       Justin Nguyen
' Date:         November 13, 2015
' Purpose:      The purpose of this program is to calculate
'               the cost of travel for one year based on 
'               mode of transportation.

Option Strict On

Public Class frmCalculateYourCommute

    Private Sub cboTransportMethod_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboTransportMethod.SelectedIndexChanged
        'This event handler allows the user to select a transport method
        'Then the program call subprocedures to acquire more information

        Dim intTransportChoice As Integer

        Select Case intTransportChoice
            Case 0
                CarChoice()
            Case 1
                TrainChoice()
            Case 2
                BusChoice()
        End Select

        btnCalculate.Visible = True
        lblDaysPerMonth.Visible = True
        txtDaysPerMonth.Visible = True

    End Sub

    Private Sub CarChoice()
        lblMpg.Visible = True
        txtMpg.Visible = True
        lblCostPerGallon.Visible = True
        txtCostPerGallon.Visible = True
        lblMaintInsuranceCost.Visible = True
        txtInsMaint.Visible = True
        lblParkingCost.Visible = True
        txtParkingCost.Visible = True
        lblDailyRTDistance.Visible = True
        txtDailyRTDistance.Visible = True
    End Sub

    Private Sub TrainChoice()
        lblRoundTripFare.Visible = True
        txtRTFare.Visible = True
    End Sub

    Private Sub BusChoice()
        lblRoundTripFare.Visible = True
        txtRTFare.Visible = True
    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim intTransportChoice As Integer
        Dim intDaysWorkedPerMonth As Integer
        Dim decCostPerGallon As Decimal
        Dim decMpg As Decimal
        Dim decDailyRtDistance As Decimal
        Dim decMonthlyMaintCost As Decimal
        Dim decMonthlyParkingCost As Decimal
        Dim decRTFare As Decimal
        Dim decMonths As Decimal = 12D
        Dim decYearlyCost As Decimal
        Dim decMonthlyTransportCost As Decimal

        intDaysWorkedPerMonth = Convert.ToInt32(txtDaysPerMonth.Text)
        decDailyRtDistance = Convert.ToDecimal(txtDailyRTDistance.Text)
        decMpg = Convert.ToDecimal(txtMpg.Text)
        decCostPerGallon = Convert.ToDecimal(txtCostPerGallon.Text)
        decMonthlyMaintCost = Convert.ToDecimal(txtInsMaint.Text)
        decMonthlyParkingCost = Convert.ToDecimal(txtParkingCost.Text)
        decRTFare = Convert.ToDecimal(txtDailyRTDistance.Text)



        intTransportChoice = cboTransportMethod.SelectedIndex
        Select Case intTransportChoice
            Case 0
                decMonthlyTransportCost = CarCost(decDailyRtDistance, decMpg, decCostPerGallon, intDaysWorkedPerMonth, decMonthlyMaintCost, decMonthlyParkingCost)
            Case 1
                decMonthlyTransportCost = TrainCost(decRTFare, intDaysWorkedPerMonth)
            Case 2
                decMonthlyTransportCost = BusCost(decRTFare, intDaysWorkedPerMonth)
        End Select

        decYearlyCost = decMonthlyTransportCost * decMonths
        lblCostDisplay.Text = decYearlyCost.ToString("C")
        lblCostDisplay.Visible = True
        lblCost.Visible = True


    End Sub

    Private Function CarCost(ByVal decDailyRtDistance As Decimal, ByVal decMpg As Decimal, ByVal decCostPerGallon As Decimal, ByVal intDaysWorkedPerMonth As Integer, ByVal decMonthlyMaintCost As Decimal, ByVal decMonthlyParkingCost As Decimal) As Decimal
        Dim decMonthlyCost As Decimal
        Dim decGallonsNeeded As Decimal
        Dim decCostOfTotalGallons As Decimal

        decGallonsNeeded = decDailyRtDistance / decMpg
        decCostOfTotalGallons = decGallonsNeeded * decCostPerGallon
        decMonthlyCost = decCostOfTotalGallons * intDaysWorkedPerMonth

        Return decMonthlyCost

    End Function

    Private Function TrainCost(ByVal decRTFare As Decimal, ByVal intDaysWorkedPerMonth As Integer) As Decimal
        Dim decMonthlyCost As Decimal

        decMonthlyCost = decRTFare * intDaysWorkedPerMonth

        Return decMonthlyCost
    End Function

    Private Function BusCost(ByVal decRTFare As Decimal, ByVal intDaysWorkedPerMonth As Integer) As Decimal
        Dim decMonthlyCost As Decimal

        decMonthlyCost = decRTFare * intDaysWorkedPerMonth

        Return decMonthlyCost
    End Function


End Class
