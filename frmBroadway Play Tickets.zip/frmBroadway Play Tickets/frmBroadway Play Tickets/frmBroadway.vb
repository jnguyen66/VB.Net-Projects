﻿' Program Name: Broadway
' Author:       Justin Nguyen
' Date:         November 10, 2015
' Purpose:      The Broadway application determines the
'               theater shows availible and calculates the cost of the show.

Option Strict On

Public Class frmBroadway
       

   
    
    Private Sub cboBroadway_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboBroadway.SelectedIndexChanged
 


        lblTicketNumber.Visible = True
        radMezzanine.Visible = True
        radOrchestra.Visible = True
        btnCalculate.Visible = True
        txtTicNumber.Visible = True

        txtTicNumber.Focus()

    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click

        Dim intTicNumber As Integer
        Dim intTheaterChoice As Integer
        Dim decTax As Decimal
        Dim decTaxRate As Decimal = 0.12D
        Dim decSub As Decimal
        Dim decFinalCost As Decimal
        Dim intSeatChoice As Integer
        Dim blnValidateNumberOfSeats As Boolean = False
        Dim blnValidateTypeSelected As Boolean = False

        'Call a function to ensure the number of seats is positive and whole
        blnValidateNumberOfSeats = ValidateNumberOfSeats()
        'Call a function to ensure a seat type was selected
        blnValidateTypeSelected = ValidateSeatTypeSelected()

        If (blnValidateNumberOfSeats And blnValidateTypeSelected) Then
            intTicNumber = Convert.ToInt32(txtTicNumber.Text)
            intTheaterChoice = cboBroadway.SelectedIndex
            Select Case intTheaterChoice
                Case 0
                    decSub = LionKingFindCost(intSeatChoice, intTicNumber)
                Case 1
                    decSub = WickedFindCost(intSeatChoice, intTicNumber)
                Case 2
                    decSub = PhantomFindCost(intSeatChoice, intTicNumber)
            End Select

            decTax = CalculateTax(decSub, decTaxRate)
            decFinalCost = decTax + decSub
            lblSubDisplay.Text = decSub.ToString("C")
            lblTaxDisplay.Text = decTax.ToString("C")
            lblTotalDisplay.Text = decFinalCost.ToString("C")
            lblSubDisplay.Visible = True
            lblSubTotal.Visible = True
            lblTax.Visible = True
            lblTaxDisplay.Visible = True
            lblTotal.Visible = True
            lblTotalDisplay.Visible = True
        End If

        
    End Sub

    Private Function ValidateNumberOfSeats() As Boolean
        'This procedure validates the value entered for the number in party

        Dim intSeatNumber As Integer
        Dim blnValidateSeat As Boolean = False
        Dim strSeatNumberErrorMessage As String = "Please enter a desired positive whole number of seats"
        Dim strMessageBoxTitle As String = "Error"

        Try
            intSeatNumber = Convert.ToInt32(txtTicNumber.Text)
            If intSeatNumber > 0 Then
                blnValidateSeat = True
            Else
                MsgBox(strSeatNumberErrorMessage, , strMessageBoxTitle)
                txtTicNumber.Focus()
                txtTicNumber.Clear()
            End If
        Catch Exception As FormatException
            MsgBox(strSeatNumberErrorMessage, , strMessageBoxTitle)
            txtTicNumber.Focus()
            txtTicNumber.Clear()
        Catch Exception As OverflowException
            MsgBox(strSeatNumberErrorMessage, , strMessageBoxTitle)
            txtTicNumber.Focus()
            txtTicNumber.Clear()
        Catch Exception As SystemException
            MsgBox(strSeatNumberErrorMessage, , strMessageBoxTitle)
            txtTicNumber.Focus()
            txtTicNumber.Clear()
        End Try
        Return blnValidateSeat
    End Function

    Private Function ValidateSeatTypeSelected() As Boolean
        'This function ensures the user selected mezzanine or orchestra
        Dim blnType As Boolean = False
        Try
            If (radMezzanine.Checked Or radOrchestra.Checked) Then
                blnType = True
            Else
                MsgBox("Please select a seat type", , "Error")
                blnType = False
            End If
        Catch Exception As SystemException
            'Detects if type not selected
            MsgBox("Please select a seat type", , "Error")
            blnType = False
        End Try
        Return blnType
    End Function


    Private Function LionKingFindCost(ByVal intSeatChoice As Decimal, ByVal intTicNumber As Integer) As Decimal
        Dim decTheaterPrice As Decimal
        Dim decSubCost As Decimal
        Dim decOrchestra As Decimal = 135D
        Dim decMezzanine As Decimal = 92D

        If radMezzanine.Checked Then
            decTheaterPrice = decMezzanine
        ElseIf radOrchestra.Checked Then
            decTheaterPrice = decOrchestra
        End If
        decSubCost = decTheaterPrice * intTicNumber
        Return decSubCost
    End Function


    Private Function WickedFindCost(ByVal intSeatChoice As Integer, ByVal intTicNumber As Integer) As Decimal
        Dim decTheaterPrice As Decimal
        Dim decSubCost As Decimal
        Dim decOrchestra As Decimal = 149D
        Dim decMezzanine As Decimal = 98D

        If radMezzanine.Checked Then
            decTheaterPrice = decMezzanine
        ElseIf radOrchestra.Checked Then
            decTheaterPrice = decOrchestra
        End If
        decSubCost = decTheaterPrice * intTicNumber
        Return decSubCost

    End Function

    Private Function PhantomFindCost(ByVal intSeatChoice As Integer, ByVal intTicNumber As Integer) As Decimal
        Dim decTheaterPrice As Decimal
        Dim decSubCost As Decimal
        Dim decOrchestra As Decimal = 128D
        Dim decMezzanine As Decimal = 82D

        If radMezzanine.Checked Then
            decTheaterPrice = decMezzanine
        ElseIf radOrchestra.Checked Then
            decTheaterPrice = decOrchestra
        End If
        decSubCost = decTheaterPrice * intTicNumber
        Return decSubCost
    End Function

    Private Sub frmBroadway_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Threading.Thread.Sleep(500)
    End Sub

    Private Function CalculateTax(ByVal decSub As Decimal, ByVal decTaxRate As Decimal) As Decimal
        Dim tax As Decimal
        tax = decSub * decTaxRate
        Return tax
    End Function
End Class
