﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBroadway
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmBroadway))
        Me.lblHeading = New System.Windows.Forms.Label()
        Me.cboBroadway = New System.Windows.Forms.ComboBox()
        Me.lblTicketNumber = New System.Windows.Forms.Label()
        Me.txtTicNumber = New System.Windows.Forms.TextBox()
        Me.radOrchestra = New System.Windows.Forms.RadioButton()
        Me.radMezzanine = New System.Windows.Forms.RadioButton()
        Me.lblSubTotal = New System.Windows.Forms.Label()
        Me.lblSubDisplay = New System.Windows.Forms.Label()
        Me.lblTax = New System.Windows.Forms.Label()
        Me.lblTaxDisplay = New System.Windows.Forms.Label()
        Me.lblTotal = New System.Windows.Forms.Label()
        Me.lblTotalDisplay = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.btnCalculate = New System.Windows.Forms.Button()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblHeading
        '
        Me.lblHeading.AutoSize = True
        Me.lblHeading.Location = New System.Drawing.Point(248, 9)
        Me.lblHeading.Name = "lblHeading"
        Me.lblHeading.Size = New System.Drawing.Size(115, 13)
        Me.lblHeading.TabIndex = 0
        Me.lblHeading.Text = "Broadway Play Tickets"
        '
        'cboBroadway
        '
        Me.cboBroadway.FormattingEnabled = True
        Me.cboBroadway.Items.AddRange(New Object() {"Lion Kings", "Wicked", "Phantom of the Opera"})
        Me.cboBroadway.Location = New System.Drawing.Point(242, 48)
        Me.cboBroadway.Name = "cboBroadway"
        Me.cboBroadway.Size = New System.Drawing.Size(134, 21)
        Me.cboBroadway.TabIndex = 1
        Me.cboBroadway.Text = "Select Broadway Play:"
        '
        'lblTicketNumber
        '
        Me.lblTicketNumber.AutoSize = True
        Me.lblTicketNumber.Location = New System.Drawing.Point(242, 86)
        Me.lblTicketNumber.Name = "lblTicketNumber"
        Me.lblTicketNumber.Size = New System.Drawing.Size(125, 13)
        Me.lblTicketNumber.TabIndex = 2
        Me.lblTicketNumber.Text = "Enter Number of Tickets:"
        Me.lblTicketNumber.Visible = False
        '
        'txtTicNumber
        '
        Me.txtTicNumber.Location = New System.Drawing.Point(283, 102)
        Me.txtTicNumber.Name = "txtTicNumber"
        Me.txtTicNumber.Size = New System.Drawing.Size(68, 20)
        Me.txtTicNumber.TabIndex = 3
        Me.txtTicNumber.Visible = False
        '
        'radOrchestra
        '
        Me.radOrchestra.AutoSize = True
        Me.radOrchestra.Location = New System.Drawing.Point(240, 137)
        Me.radOrchestra.Name = "radOrchestra"
        Me.radOrchestra.Size = New System.Drawing.Size(71, 17)
        Me.radOrchestra.TabIndex = 4
        Me.radOrchestra.TabStop = True
        Me.radOrchestra.Text = "Orchestra"
        Me.radOrchestra.UseVisualStyleBackColor = True
        Me.radOrchestra.Visible = False
        '
        'radMezzanine
        '
        Me.radMezzanine.AutoSize = True
        Me.radMezzanine.Location = New System.Drawing.Point(353, 137)
        Me.radMezzanine.Name = "radMezzanine"
        Me.radMezzanine.Size = New System.Drawing.Size(76, 17)
        Me.radMezzanine.TabIndex = 5
        Me.radMezzanine.TabStop = True
        Me.radMezzanine.Text = "Mezzanine"
        Me.radMezzanine.UseVisualStyleBackColor = True
        Me.radMezzanine.Visible = False
        '
        'lblSubTotal
        '
        Me.lblSubTotal.AutoSize = True
        Me.lblSubTotal.Location = New System.Drawing.Point(248, 253)
        Me.lblSubTotal.Name = "lblSubTotal"
        Me.lblSubTotal.Size = New System.Drawing.Size(56, 13)
        Me.lblSubTotal.TabIndex = 6
        Me.lblSubTotal.Text = "Sub Total:"
        Me.lblSubTotal.Visible = False
        '
        'lblSubDisplay
        '
        Me.lblSubDisplay.AutoSize = True
        Me.lblSubDisplay.Location = New System.Drawing.Point(401, 253)
        Me.lblSubDisplay.Name = "lblSubDisplay"
        Me.lblSubDisplay.Size = New System.Drawing.Size(46, 13)
        Me.lblSubDisplay.TabIndex = 7
        Me.lblSubDisplay.Text = "$888.88"
        Me.lblSubDisplay.Visible = False
        '
        'lblTax
        '
        Me.lblTax.AutoSize = True
        Me.lblTax.Location = New System.Drawing.Point(248, 279)
        Me.lblTax.Name = "lblTax"
        Me.lblTax.Size = New System.Drawing.Size(28, 13)
        Me.lblTax.TabIndex = 8
        Me.lblTax.Text = "Tax:"
        Me.lblTax.Visible = False
        '
        'lblTaxDisplay
        '
        Me.lblTaxDisplay.AutoSize = True
        Me.lblTaxDisplay.Location = New System.Drawing.Point(401, 279)
        Me.lblTaxDisplay.Name = "lblTaxDisplay"
        Me.lblTaxDisplay.Size = New System.Drawing.Size(46, 13)
        Me.lblTaxDisplay.TabIndex = 9
        Me.lblTaxDisplay.Text = "$888.88"
        Me.lblTaxDisplay.Visible = False
        '
        'lblTotal
        '
        Me.lblTotal.AutoSize = True
        Me.lblTotal.Location = New System.Drawing.Point(247, 303)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(59, 13)
        Me.lblTotal.TabIndex = 10
        Me.lblTotal.Text = "Final Total:"
        Me.lblTotal.Visible = False
        '
        'lblTotalDisplay
        '
        Me.lblTotalDisplay.AutoSize = True
        Me.lblTotalDisplay.Location = New System.Drawing.Point(401, 303)
        Me.lblTotalDisplay.Name = "lblTotalDisplay"
        Me.lblTotalDisplay.Size = New System.Drawing.Size(46, 13)
        Me.lblTotalDisplay.TabIndex = 11
        Me.lblTotalDisplay.Text = "$888.88"
        Me.lblTotalDisplay.Visible = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(1, 12)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(217, 196)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 12
        Me.PictureBox1.TabStop = False
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(343, 185)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(75, 23)
        Me.btnCalculate.TabIndex = 13
        Me.btnCalculate.Text = "Calculate Cost"
        Me.btnCalculate.UseVisualStyleBackColor = True
        Me.btnCalculate.Visible = False
        '
        'frmBroadway
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(459, 325)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.lblTotalDisplay)
        Me.Controls.Add(Me.lblTotal)
        Me.Controls.Add(Me.lblTaxDisplay)
        Me.Controls.Add(Me.lblTax)
        Me.Controls.Add(Me.lblSubDisplay)
        Me.Controls.Add(Me.lblSubTotal)
        Me.Controls.Add(Me.radMezzanine)
        Me.Controls.Add(Me.radOrchestra)
        Me.Controls.Add(Me.txtTicNumber)
        Me.Controls.Add(Me.lblTicketNumber)
        Me.Controls.Add(Me.cboBroadway)
        Me.Controls.Add(Me.lblHeading)
        Me.Name = "frmBroadway"
        Me.Text = "Broadway Play Tickets"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblHeading As System.Windows.Forms.Label
    Friend WithEvents cboBroadway As System.Windows.Forms.ComboBox
    Friend WithEvents lblTicketNumber As System.Windows.Forms.Label
    Friend WithEvents txtTicNumber As System.Windows.Forms.TextBox
    Friend WithEvents radOrchestra As System.Windows.Forms.RadioButton
    Friend WithEvents radMezzanine As System.Windows.Forms.RadioButton
    Friend WithEvents lblSubTotal As System.Windows.Forms.Label
    Friend WithEvents lblSubDisplay As System.Windows.Forms.Label
    Friend WithEvents lblTax As System.Windows.Forms.Label
    Friend WithEvents lblTaxDisplay As System.Windows.Forms.Label
    Friend WithEvents lblTotal As System.Windows.Forms.Label
    Friend WithEvents lblTotalDisplay As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents btnCalculate As System.Windows.Forms.Button

End Class
