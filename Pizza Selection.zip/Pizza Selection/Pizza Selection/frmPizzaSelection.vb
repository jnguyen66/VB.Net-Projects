﻿Public Class frmPizzaSelection

    Private Sub frmPizzaSelection_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub lblHeading_Click(sender As Object, e As EventArgs) Handles lblHeading.Click

    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles picThinCrust.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnDeepDish.Click

    End Sub
End Class
