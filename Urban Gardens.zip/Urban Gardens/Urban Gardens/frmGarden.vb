﻿' Title:    Urban Gardens Windows Application
' Author:   Justin Nguyen
' Date:     November 27, 2015
' Purpose:  The application displays the current urban gardeners as an interface for a microsoft
'           Access database


Public Class frmGarden

    Private Sub GardenerBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles GardenerBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.GardenerBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.GardenDataSet)

    End Sub

    Private Sub frmGarden_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'GardenDataSet.Gardener' table. You can move, or remove it, as needed.
        Me.GardenerTableAdapter.Fill(Me.GardenDataSet.Gardener)

    End Sub

    Private Sub btnCost_Click(sender As Object, e As EventArgs) Handles btnCost.Click
        'strSq1 is a sql statement that selects all the fields from the gardener table
        Dim strSql As String = "Select *From Gardener"

        'strPath provides the database type and path of the Garden database
        Dim strPath As String = "Provider = Microsoft.ACE.OLEDB.12.0 ;" & "Data Source =w:\Garden.accdb"
        Dim odaGarden As New OleDb.OleDbDataAdapter(strSql, strPath)

        Dim datCost As New DataTable
        Dim intCount As Integer
        Dim decTotalCost As Decimal = 0D

        'The datatable name datCost is filled with the table data
        odaGarden.Fill(datCost)
        'The connection to the database is disconnected
        odaGarden.Dispose()

        For intCount = 0 To datCost.Rows.Count - 1
            decTotalCost += Convert.ToDecimal(datCost.Rows(intCount)("Cost"))
        Next
        lblTotalPlantingCost.Visible = True
        lblTotalPlantingCost.Text = "The Total Planting Cost is " & decTotalCost.ToString("C")

    End Sub
End Class
