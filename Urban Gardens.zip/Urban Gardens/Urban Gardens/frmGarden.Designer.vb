﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmGarden
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmGarden))
        Dim Plot_IDLabel As System.Windows.Forms.Label
        Dim LocationLabel As System.Windows.Forms.Label
        Dim Gardener_NameLabel As System.Windows.Forms.Label
        Dim Plot_OwnershipLabel As System.Windows.Forms.Label
        Dim Urban_Garden_NameLabel As System.Windows.Forms.Label
        Dim CostLabel As System.Windows.Forms.Label
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.lblHeading = New System.Windows.Forms.Label()
        Me.GardenDataSet = New Urban_Gardens.GardenDataSet()
        Me.GardenerBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.GardenerTableAdapter = New Urban_Gardens.GardenDataSetTableAdapters.GardenerTableAdapter()
        Me.TableAdapterManager = New Urban_Gardens.GardenDataSetTableAdapters.TableAdapterManager()
        Me.GardenerBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.GardenerBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.Plot_IDTextBox = New System.Windows.Forms.TextBox()
        Me.LocationTextBox = New System.Windows.Forms.TextBox()
        Me.Gardener_NameTextBox = New System.Windows.Forms.TextBox()
        Me.Plot_OwnershipTextBox = New System.Windows.Forms.TextBox()
        Me.Urban_Garden_NameTextBox = New System.Windows.Forms.TextBox()
        Me.CostTextBox = New System.Windows.Forms.TextBox()
        Me.btnCost = New System.Windows.Forms.Button()
        Me.lblTotalPlantingCost = New System.Windows.Forms.Label()
        Plot_IDLabel = New System.Windows.Forms.Label()
        LocationLabel = New System.Windows.Forms.Label()
        Gardener_NameLabel = New System.Windows.Forms.Label()
        Plot_OwnershipLabel = New System.Windows.Forms.Label()
        Urban_Garden_NameLabel = New System.Windows.Forms.Label()
        CostLabel = New System.Windows.Forms.Label()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GardenDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GardenerBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GardenerBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GardenerBindingNavigator.SuspendLayout()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(12, 25)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(218, 149)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'lblHeading
        '
        Me.lblHeading.AutoSize = True
        Me.lblHeading.Font = New System.Drawing.Font("Script MT Bold", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHeading.ForeColor = System.Drawing.Color.ForestGreen
        Me.lblHeading.Location = New System.Drawing.Point(315, 38)
        Me.lblHeading.Name = "lblHeading"
        Me.lblHeading.Size = New System.Drawing.Size(232, 42)
        Me.lblHeading.TabIndex = 1
        Me.lblHeading.Text = "Urban Gardens"
        '
        'GardenDataSet
        '
        Me.GardenDataSet.DataSetName = "GardenDataSet"
        Me.GardenDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'GardenerBindingSource
        '
        Me.GardenerBindingSource.DataMember = "Gardener"
        Me.GardenerBindingSource.DataSource = Me.GardenDataSet
        '
        'GardenerTableAdapter
        '
        Me.GardenerTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.GardenerTableAdapter = Me.GardenerTableAdapter
        Me.TableAdapterManager.UpdateOrder = Urban_Gardens.GardenDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'GardenerBindingNavigator
        '
        Me.GardenerBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.GardenerBindingNavigator.BindingSource = Me.GardenerBindingSource
        Me.GardenerBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.GardenerBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.GardenerBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.GardenerBindingNavigatorSaveItem})
        Me.GardenerBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.GardenerBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.GardenerBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.GardenerBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.GardenerBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.GardenerBindingNavigator.Name = "GardenerBindingNavigator"
        Me.GardenerBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.GardenerBindingNavigator.Size = New System.Drawing.Size(664, 25)
        Me.GardenerBindingNavigator.TabIndex = 2
        Me.GardenerBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 23)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(35, 22)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Delete"
        '
        'GardenerBindingNavigatorSaveItem
        '
        Me.GardenerBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.GardenerBindingNavigatorSaveItem.Image = CType(resources.GetObject("GardenerBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.GardenerBindingNavigatorSaveItem.Name = "GardenerBindingNavigatorSaveItem"
        Me.GardenerBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.GardenerBindingNavigatorSaveItem.Text = "Save Data"
        '
        'Plot_IDLabel
        '
        Plot_IDLabel.AutoSize = True
        Plot_IDLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Plot_IDLabel.Location = New System.Drawing.Point(12, 201)
        Plot_IDLabel.Name = "Plot_IDLabel"
        Plot_IDLabel.Size = New System.Drawing.Size(50, 16)
        Plot_IDLabel.TabIndex = 3
        Plot_IDLabel.Text = "Plot ID:"
        '
        'Plot_IDTextBox
        '
        Me.Plot_IDTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.GardenerBindingSource, "Plot ID", True))
        Me.Plot_IDTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Plot_IDTextBox.Location = New System.Drawing.Point(156, 195)
        Me.Plot_IDTextBox.Name = "Plot_IDTextBox"
        Me.Plot_IDTextBox.Size = New System.Drawing.Size(153, 22)
        Me.Plot_IDTextBox.TabIndex = 4
        '
        'LocationLabel
        '
        LocationLabel.AutoSize = True
        LocationLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        LocationLabel.Location = New System.Drawing.Point(337, 198)
        LocationLabel.Name = "LocationLabel"
        LocationLabel.Size = New System.Drawing.Size(62, 16)
        LocationLabel.TabIndex = 5
        LocationLabel.Text = "Location:"
        '
        'LocationTextBox
        '
        Me.LocationTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.GardenerBindingSource, "Location", True))
        Me.LocationTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LocationTextBox.Location = New System.Drawing.Point(446, 198)
        Me.LocationTextBox.Name = "LocationTextBox"
        Me.LocationTextBox.Size = New System.Drawing.Size(206, 22)
        Me.LocationTextBox.TabIndex = 6
        '
        'Gardener_NameLabel
        '
        Gardener_NameLabel.AutoSize = True
        Gardener_NameLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Gardener_NameLabel.Location = New System.Drawing.Point(12, 237)
        Gardener_NameLabel.Name = "Gardener_NameLabel"
        Gardener_NameLabel.Size = New System.Drawing.Size(108, 16)
        Gardener_NameLabel.TabIndex = 7
        Gardener_NameLabel.Text = "Gardener Name:"
        '
        'Gardener_NameTextBox
        '
        Me.Gardener_NameTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.GardenerBindingSource, "Gardener Name", True))
        Me.Gardener_NameTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Gardener_NameTextBox.Location = New System.Drawing.Point(156, 234)
        Me.Gardener_NameTextBox.Name = "Gardener_NameTextBox"
        Me.Gardener_NameTextBox.Size = New System.Drawing.Size(153, 22)
        Me.Gardener_NameTextBox.TabIndex = 8
        '
        'Plot_OwnershipLabel
        '
        Plot_OwnershipLabel.AutoSize = True
        Plot_OwnershipLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Plot_OwnershipLabel.Location = New System.Drawing.Point(337, 234)
        Plot_OwnershipLabel.Name = "Plot_OwnershipLabel"
        Plot_OwnershipLabel.Size = New System.Drawing.Size(100, 16)
        Plot_OwnershipLabel.TabIndex = 9
        Plot_OwnershipLabel.Text = "Plot Ownership:"
        '
        'Plot_OwnershipTextBox
        '
        Me.Plot_OwnershipTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.GardenerBindingSource, "Plot Ownership", True))
        Me.Plot_OwnershipTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Plot_OwnershipTextBox.Location = New System.Drawing.Point(446, 231)
        Me.Plot_OwnershipTextBox.Name = "Plot_OwnershipTextBox"
        Me.Plot_OwnershipTextBox.Size = New System.Drawing.Size(206, 22)
        Me.Plot_OwnershipTextBox.TabIndex = 10
        '
        'Urban_Garden_NameLabel
        '
        Urban_Garden_NameLabel.AutoSize = True
        Urban_Garden_NameLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Urban_Garden_NameLabel.Location = New System.Drawing.Point(12, 281)
        Urban_Garden_NameLabel.Name = "Urban_Garden_NameLabel"
        Urban_Garden_NameLabel.Size = New System.Drawing.Size(136, 16)
        Urban_Garden_NameLabel.TabIndex = 11
        Urban_Garden_NameLabel.Text = "Urban Garden Name:"
        '
        'Urban_Garden_NameTextBox
        '
        Me.Urban_Garden_NameTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.GardenerBindingSource, "Urban Garden Name", True))
        Me.Urban_Garden_NameTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Urban_Garden_NameTextBox.Location = New System.Drawing.Point(156, 278)
        Me.Urban_Garden_NameTextBox.Name = "Urban_Garden_NameTextBox"
        Me.Urban_Garden_NameTextBox.Size = New System.Drawing.Size(153, 22)
        Me.Urban_Garden_NameTextBox.TabIndex = 12
        '
        'CostLabel
        '
        CostLabel.AutoSize = True
        CostLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        CostLabel.Location = New System.Drawing.Point(337, 277)
        CostLabel.Name = "CostLabel"
        CostLabel.Size = New System.Drawing.Size(38, 16)
        CostLabel.TabIndex = 13
        CostLabel.Text = "Cost:"
        '
        'CostTextBox
        '
        Me.CostTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.GardenerBindingSource, "Cost", True))
        Me.CostTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CostTextBox.Location = New System.Drawing.Point(446, 274)
        Me.CostTextBox.Name = "CostTextBox"
        Me.CostTextBox.Size = New System.Drawing.Size(206, 22)
        Me.CostTextBox.TabIndex = 14
        '
        'btnCost
        '
        Me.btnCost.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCost.ForeColor = System.Drawing.Color.ForestGreen
        Me.btnCost.Location = New System.Drawing.Point(256, 317)
        Me.btnCost.Name = "btnCost"
        Me.btnCost.Size = New System.Drawing.Size(152, 37)
        Me.btnCost.TabIndex = 15
        Me.btnCost.Text = "Total Planting Cost"
        Me.btnCost.UseVisualStyleBackColor = True
        '
        'lblTotalPlantingCost
        '
        Me.lblTotalPlantingCost.AutoSize = True
        Me.lblTotalPlantingCost.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotalPlantingCost.ForeColor = System.Drawing.Color.ForestGreen
        Me.lblTotalPlantingCost.Location = New System.Drawing.Point(109, 372)
        Me.lblTotalPlantingCost.Name = "lblTotalPlantingCost"
        Me.lblTotalPlantingCost.Size = New System.Drawing.Size(460, 24)
        Me.lblTotalPlantingCost.TabIndex = 16
        Me.lblTotalPlantingCost.Text = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
        Me.lblTotalPlantingCost.Visible = False
        '
        'frmGarden
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(664, 420)
        Me.Controls.Add(Me.lblTotalPlantingCost)
        Me.Controls.Add(Me.btnCost)
        Me.Controls.Add(CostLabel)
        Me.Controls.Add(Me.CostTextBox)
        Me.Controls.Add(Urban_Garden_NameLabel)
        Me.Controls.Add(Me.Urban_Garden_NameTextBox)
        Me.Controls.Add(Plot_OwnershipLabel)
        Me.Controls.Add(Me.Plot_OwnershipTextBox)
        Me.Controls.Add(Gardener_NameLabel)
        Me.Controls.Add(Me.Gardener_NameTextBox)
        Me.Controls.Add(LocationLabel)
        Me.Controls.Add(Me.LocationTextBox)
        Me.Controls.Add(Plot_IDLabel)
        Me.Controls.Add(Me.Plot_IDTextBox)
        Me.Controls.Add(Me.GardenerBindingNavigator)
        Me.Controls.Add(Me.lblHeading)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "frmGarden"
        Me.Text = "Urban Gardening"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GardenDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GardenerBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GardenerBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GardenerBindingNavigator.ResumeLayout(False)
        Me.GardenerBindingNavigator.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents lblHeading As System.Windows.Forms.Label
    Friend WithEvents GardenDataSet As Urban_Gardens.GardenDataSet
    Friend WithEvents GardenerBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents GardenerTableAdapter As Urban_Gardens.GardenDataSetTableAdapters.GardenerTableAdapter
    Friend WithEvents TableAdapterManager As Urban_Gardens.GardenDataSetTableAdapters.TableAdapterManager
    Friend WithEvents GardenerBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents GardenerBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents Plot_IDTextBox As System.Windows.Forms.TextBox
    Friend WithEvents LocationTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Gardener_NameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Plot_OwnershipTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Urban_Garden_NameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents CostTextBox As System.Windows.Forms.TextBox
    Friend WithEvents btnCost As System.Windows.Forms.Button
    Friend WithEvents lblTotalPlantingCost As System.Windows.Forms.Label

End Class
