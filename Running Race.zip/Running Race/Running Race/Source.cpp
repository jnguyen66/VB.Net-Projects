#include <iostream>
#include <string>
#include <iomanip>

using namespace std;

int main()
{
	string studentName1;
	string studentName2;
	string studentName3;
	float time1;
	float time2;
	float time3;
	string place1;
	string place2;
	string place3;


	cout << "Please enter first student name.\n";
	cin >> studentName1;
	cout << "Please enter seconds taken to finish race for " << studentName1 << "\n";
	cin >> time1;
	cout << "Please second student name.\n";
	cin >> studentName2;
	cout << "Please enter seconds taken to finish race for " << studentName2 << "\n";
	cin >> time2;
	cout << "Please third student name.\n";
	cin >> studentName3;
	cout << "Please enter seconds taken to finish race for " << studentName3 << "\n";
	cin >> time3;

	if (time1<time2)
	{
		if (time1<time3)
		{
			place1 = "First Place.\n";
			if (time2<time3)
			{
				place2 = "Second Place.\n";
				place3 ="Third Place.\n";
			}
			else
			{
				place3 = "Second Place.\n";
				place2 ="Third Place.\n";
			}
		}
		else
		{
			place1 = "Second Place.\n";
			place2="Third Place. \n";
			place3="First Place.\n";
		}
	}
	else
	{
		if (time2<time3)
		{
			place2="First Place.\n";
			if (time3<time1)
			{
				place3 = "Second Place.\n";
				place1="Third Place. \n";
			}
			else
				place1 = "Second Place.\n";
				place3="Third Place. \n";

		}
		else
		{
			place3="First Place.\n";
			place2="Second Place.\n";
			place1="Third Place. \n";
		}

	}

	cout << "Student " << studentName1<< " came in " << place1 << "\n";
	cout << "Student " << studentName2<< " came in " << place2 << "\n";
	cout << "Student " << studentName3<< " came in " << place3 << "\n";
	return 0;

}