﻿' Program Name: Snowfall In Buffalo
' Author:       Justin Nguyen
' Date:         October 27th, 2015
' Purpose:      The Snowfall in Buffalo program enters the inches of snowfall
'               between october and April. It displays each month in a list
'               and the total for the months entered

Option Strict On

Public Class frmSnowfall

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        'The btnCalculate button accepts and displays inches of snow
        'and then calculates and displays the total for the months entered

        'Declare Variables
        Dim strSnowFall As String
        Dim decSnowFall As Decimal
        Dim decTotalSnowFall As Decimal = 0D
        Dim strInputMessage As String = "Enter the snowfall for month #"
        Dim strInputHeading As String = "Snowfall in Inches"
        Dim strNormalMessgae As String = "Enter the snowfall for month #"
        Dim strNonNumericError As String = "Error-Enter a number for snowfall of month #"
        Dim strNegativeError As String = "Error-Enter a positive number for the snowfall of month #"

        'Declare and Initialize loop variables
        Dim strCancelClicked As String = ""
        Dim intMaxNumberOfEntries As Integer = 7
        Dim intNumberOfEntries As Integer = 1

        'This loop allows the user to enter the weight loss of up to 8 team members. 
        'The loop terminates when the user has evetred 8 weight loss values or the user
        'taps or clicks the cancel button or the close button in the input box

        strSnowFall = InputBox(strInputMessage & intNumberOfEntries, strInputHeading, " ")

        Do Until intNumberOfEntries > intMaxNumberOfEntries Or strSnowFall = strCancelClicked
            If IsNumeric(strSnowFall) Then
                decSnowFall = Convert.ToDecimal(strSnowFall)
                If decSnowFall > 0 Then
                    lstSnowfall.Items.Add(decSnowFall)
                    decTotalSnowFall += decSnowFall
                    intNumberOfEntries += 1
                    strInputMessage = strNormalMessgae
                Else
                    strInputMessage = strNegativeError
                End If
            Else
                strInputMessage = strNonNumericError
            End If

            If intNumberOfEntries <= intMaxNumberOfEntries Then
                strSnowFall = InputBox(strInputMessage & intNumberOfEntries, strInputHeading, " ")
            End If
        Loop

        'Displays Total
        If intNumberOfEntries > 1 Then
            lblTotal.Visible = True
            lblTotal.Text = "The total snowfall is " & decTotalSnowFall.ToString("F1") & " inches"
        Else
            MsgBox("No snow fall value entered")
        End If

        'Disables the weight loss button
        btnCalculate.Enabled = False
    End Sub

    Private Sub mnuClear_Click(sender As Object, e As EventArgs) Handles mnuClear.Click
        'The mnuClear clears the list box and hides 
        'the total weight loss label. It also enables 
        'the weight loss button

        lstSnowfall.Items.Clear()
        lblTotal.Visible = False
        btnCalculate.Enabled = True

    End Sub

    Private Sub mnuExit_Click(sender As Object, e As EventArgs) Handles mnuExit.Click
        'The mnuExit click event closes the window and exits the application

        Close()
    End Sub
End Class
