﻿'Program:   Sales Tax Calc App
'Author:    Justin Nguyen
'Date:      Septemeber 29th, 2015
'Purpose:   The application calculate and displays
'           sales tax, item name, and final cost

Option Strict On

Public Class frmSalesTaxCalcApp
    Const _cdecTaxRate As Decimal = 0.09D

    Private Sub btnDisplayCost_Click(sender As Object, e As EventArgs) Handles btnDisplayCost.Click
        'This even handler is executed when the user clicks the display 
        'button. It calculates and diplays the name, cost, tax, and final
        'cost. (Cost times tax rate plus cost)

        Dim strNameOfItem As String
        Dim strCostOfItem As String
        Dim decCostOfItem As Decimal
        Dim decTotalCost As Decimal
        Dim decTaxCost As Decimal

        strNameOfItem = txtName.Text
        strCostOfItem = txtBeforeTaxCost.Text
        decCostOfItem = Convert.ToDecimal(strCostOfItem)
        decTaxCost = decCostOfItem * _cdecTaxRate
        decTotalCost = decTaxCost + decCostOfItem
        lblFinalCostDisplay.Text = decTotalCost.ToString("C")
        lblCostDisplay.Text = decCostOfItem.ToString("C")
        lblTaxDisplay.Text = decTaxCost.ToString("C")
        lblNameDisplay.Text = strNameOfItem
        lblCost.Text = "Cost"
        lblTax.Text = "Cost"
        lblFinalCost.Text = "Final Cost"

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'Closes and exits application

        Close()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'This event handler is executed when the user clicks the
        'clear button. It clears the name of item text box, 
        'before tax cost text box, total cost display, tax
        'display, and cost display. Also focuses on name
        'text box.

        lblFinalCostDisplay.Text = ""
        lblCostDisplay.Text = ""
        lblTaxDisplay.Text = ""
        lblNameDisplay.Text = ""
        lblCost.Text = ""
        lblTax.Text = ""
        lblFinalCost.Text = ""
        txtName.Focus()
        txtName.Text = ""
        txtBeforeTaxCost.Text = ""


    End Sub

    Private Sub frmSalesTaxCalcApp_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'This event handler is executed when the form is loaded
        'It clears the display labels for the name, final cost
        ', tax cost, cost, and respective prices. Also sets the 
        'focus on the name Textbox object.

        lblFinalCostDisplay.Text = ""
        lblCostDisplay.Text = ""
        lblTaxDisplay.Text = ""
        lblNameDisplay.Text = ""
        lblCost.Text = ""
        lblTax.Text = ""
        lblFinalCost.Text = ""
        txtName.Focus()

    End Sub
End Class
