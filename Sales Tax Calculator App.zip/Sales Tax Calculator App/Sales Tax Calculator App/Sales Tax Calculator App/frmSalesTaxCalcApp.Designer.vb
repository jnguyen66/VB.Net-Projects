﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSalesTaxCalcApp
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmSalesTaxCalcApp))
        Me.lblHeading = New System.Windows.Forms.Label()
        Me.lblItemName = New System.Windows.Forms.Label()
        Me.lblBeforeTaxCost = New System.Windows.Forms.Label()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.txtBeforeTaxCost = New System.Windows.Forms.TextBox()
        Me.picStore = New System.Windows.Forms.PictureBox()
        Me.btnDisplayCost = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblTax = New System.Windows.Forms.Label()
        Me.lblTaxDisplay = New System.Windows.Forms.Label()
        Me.lblCost = New System.Windows.Forms.Label()
        Me.lblCostDisplay = New System.Windows.Forms.Label()
        Me.lblFinalCost = New System.Windows.Forms.Label()
        Me.lblFinalCostDisplay = New System.Windows.Forms.Label()
        Me.lblNameDisplay = New System.Windows.Forms.Label()
        CType(Me.picStore, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblHeading
        '
        Me.lblHeading.AutoSize = True
        Me.lblHeading.Font = New System.Drawing.Font("Modern No. 20", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHeading.Location = New System.Drawing.Point(165, 9)
        Me.lblHeading.Name = "lblHeading"
        Me.lblHeading.Size = New System.Drawing.Size(155, 24)
        Me.lblHeading.TabIndex = 0
        Me.lblHeading.Text = "Sales Tax R Us"
        '
        'lblItemName
        '
        Me.lblItemName.AutoSize = True
        Me.lblItemName.Font = New System.Drawing.Font("Modern No. 20", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblItemName.Location = New System.Drawing.Point(12, 68)
        Me.lblItemName.Name = "lblItemName"
        Me.lblItemName.Size = New System.Drawing.Size(97, 18)
        Me.lblItemName.TabIndex = 1
        Me.lblItemName.Text = "Name of Item"
        '
        'lblBeforeTaxCost
        '
        Me.lblBeforeTaxCost.AutoSize = True
        Me.lblBeforeTaxCost.Font = New System.Drawing.Font("Modern No. 20", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBeforeTaxCost.Location = New System.Drawing.Point(12, 109)
        Me.lblBeforeTaxCost.Name = "lblBeforeTaxCost"
        Me.lblBeforeTaxCost.Size = New System.Drawing.Size(165, 18)
        Me.lblBeforeTaxCost.TabIndex = 2
        Me.lblBeforeTaxCost.Text = "Cost of Item Before Tax"
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(289, 65)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(100, 20)
        Me.txtName.TabIndex = 3
        '
        'txtBeforeTaxCost
        '
        Me.txtBeforeTaxCost.Location = New System.Drawing.Point(336, 107)
        Me.txtBeforeTaxCost.Name = "txtBeforeTaxCost"
        Me.txtBeforeTaxCost.Size = New System.Drawing.Size(53, 20)
        Me.txtBeforeTaxCost.TabIndex = 4
        '
        'picStore
        '
        Me.picStore.Image = CType(resources.GetObject("picStore.Image"), System.Drawing.Image)
        Me.picStore.Location = New System.Drawing.Point(0, 216)
        Me.picStore.Name = "picStore"
        Me.picStore.Size = New System.Drawing.Size(285, 250)
        Me.picStore.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picStore.TabIndex = 5
        Me.picStore.TabStop = False
        '
        'btnDisplayCost
        '
        Me.btnDisplayCost.Font = New System.Drawing.Font("Modern No. 20", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDisplayCost.Location = New System.Drawing.Point(314, 144)
        Me.btnDisplayCost.Name = "btnDisplayCost"
        Me.btnDisplayCost.Size = New System.Drawing.Size(75, 28)
        Me.btnDisplayCost.TabIndex = 6
        Me.btnDisplayCost.Text = "Display Cost"
        Me.btnDisplayCost.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnClear.Font = New System.Drawing.Font("Modern No. 20", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear.Location = New System.Drawing.Point(67, 144)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 28)
        Me.btnClear.TabIndex = 7
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Font = New System.Drawing.Font("Modern No. 20", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(314, 402)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 28)
        Me.btnExit.TabIndex = 8
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblTax
        '
        Me.lblTax.AutoSize = True
        Me.lblTax.Font = New System.Drawing.Font("Modern No. 20", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTax.Location = New System.Drawing.Point(311, 261)
        Me.lblTax.Name = "lblTax"
        Me.lblTax.Size = New System.Drawing.Size(66, 17)
        Me.lblTax.TabIndex = 9
        Me.lblTax.Text = "Sales Tax"
        '
        'lblTaxDisplay
        '
        Me.lblTaxDisplay.AutoSize = True
        Me.lblTaxDisplay.Font = New System.Drawing.Font("Modern No. 20", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTaxDisplay.Location = New System.Drawing.Point(394, 261)
        Me.lblTaxDisplay.Name = "lblTaxDisplay"
        Me.lblTaxDisplay.Size = New System.Drawing.Size(55, 17)
        Me.lblTaxDisplay.TabIndex = 10
        Me.lblTaxDisplay.Text = "$888.88"
        '
        'lblCost
        '
        Me.lblCost.AutoSize = True
        Me.lblCost.Font = New System.Drawing.Font("Modern No. 20", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCost.Location = New System.Drawing.Point(311, 227)
        Me.lblCost.Name = "lblCost"
        Me.lblCost.Size = New System.Drawing.Size(33, 17)
        Me.lblCost.TabIndex = 11
        Me.lblCost.Text = "Cost"
        '
        'lblCostDisplay
        '
        Me.lblCostDisplay.AutoSize = True
        Me.lblCostDisplay.Font = New System.Drawing.Font("Modern No. 20", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCostDisplay.Location = New System.Drawing.Point(394, 227)
        Me.lblCostDisplay.Name = "lblCostDisplay"
        Me.lblCostDisplay.Size = New System.Drawing.Size(55, 17)
        Me.lblCostDisplay.TabIndex = 12
        Me.lblCostDisplay.Text = "$888.88"
        '
        'lblFinalCost
        '
        Me.lblFinalCost.AutoSize = True
        Me.lblFinalCost.Font = New System.Drawing.Font("Modern No. 20", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFinalCost.Location = New System.Drawing.Point(311, 303)
        Me.lblFinalCost.Name = "lblFinalCost"
        Me.lblFinalCost.Size = New System.Drawing.Size(71, 17)
        Me.lblFinalCost.TabIndex = 13
        Me.lblFinalCost.Text = "Final Cost"
        '
        'lblFinalCostDisplay
        '
        Me.lblFinalCostDisplay.AutoSize = True
        Me.lblFinalCostDisplay.Font = New System.Drawing.Font("Modern No. 20", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFinalCostDisplay.Location = New System.Drawing.Point(394, 303)
        Me.lblFinalCostDisplay.Name = "lblFinalCostDisplay"
        Me.lblFinalCostDisplay.Size = New System.Drawing.Size(55, 17)
        Me.lblFinalCostDisplay.TabIndex = 14
        Me.lblFinalCostDisplay.Text = "$888.88"
        '
        'lblNameDisplay
        '
        Me.lblNameDisplay.AutoSize = True
        Me.lblNameDisplay.Font = New System.Drawing.Font("Modern No. 20", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNameDisplay.Location = New System.Drawing.Point(311, 192)
        Me.lblNameDisplay.Name = "lblNameDisplay"
        Me.lblNameDisplay.Size = New System.Drawing.Size(80, 18)
        Me.lblNameDisplay.TabIndex = 15
        Me.lblNameDisplay.Text = "XXXXXX"
        '
        'frmSalesTaxCalcApp
        '
        Me.AcceptButton = Me.btnDisplayCost
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.CancelButton = Me.btnClear
        Me.ClientSize = New System.Drawing.Size(484, 462)
        Me.Controls.Add(Me.lblNameDisplay)
        Me.Controls.Add(Me.lblFinalCostDisplay)
        Me.Controls.Add(Me.lblFinalCost)
        Me.Controls.Add(Me.lblCostDisplay)
        Me.Controls.Add(Me.lblCost)
        Me.Controls.Add(Me.lblTaxDisplay)
        Me.Controls.Add(Me.lblTax)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnDisplayCost)
        Me.Controls.Add(Me.picStore)
        Me.Controls.Add(Me.txtBeforeTaxCost)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.lblBeforeTaxCost)
        Me.Controls.Add(Me.lblItemName)
        Me.Controls.Add(Me.lblHeading)
        Me.Name = "frmSalesTaxCalcApp"
        Me.Text = "Sales Tax Calculator App"
        CType(Me.picStore, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblHeading As System.Windows.Forms.Label
    Friend WithEvents lblItemName As System.Windows.Forms.Label
    Friend WithEvents lblBeforeTaxCost As System.Windows.Forms.Label
    Friend WithEvents txtName As System.Windows.Forms.TextBox
    Friend WithEvents txtBeforeTaxCost As System.Windows.Forms.TextBox
    Friend WithEvents picStore As System.Windows.Forms.PictureBox
    Friend WithEvents btnDisplayCost As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents lblTax As System.Windows.Forms.Label
    Friend WithEvents lblTaxDisplay As System.Windows.Forms.Label
    Friend WithEvents lblCost As System.Windows.Forms.Label
    Friend WithEvents lblCostDisplay As System.Windows.Forms.Label
    Friend WithEvents lblFinalCost As System.Windows.Forms.Label
    Friend WithEvents lblFinalCostDisplay As System.Windows.Forms.Label
    Friend WithEvents lblNameDisplay As System.Windows.Forms.Label

End Class
