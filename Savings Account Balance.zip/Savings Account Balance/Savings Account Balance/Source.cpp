#include <iostream>
#include <string>
#include <iomanip>

using namespace std;

int main()
{
	//Create variables
	float balance;
	float deposit;
	float totalDeposits=0;
	float withdrawl;
	float totalWithdrawl=0;
	float startBalance;
	int month;

	//Acquire starting balance
	cout << "Hello, please enter your starting balance before the three month period.\n";
	cin >> startBalance;
	balance=startBalance;

	//Retrieve deposits and withdrawls from user three times
	for (month=1; month<4; month++)
	{
		cout << "Now enter the amount of money deposited for month " << month << "\n";
		cin >> deposit;
		if (deposit>=0)
		{
			balance=balance + deposit;
			totalDeposits=totalDeposits+deposit;
		}
		else
			cout << "Deposit amount entered is less than 0, therefore deposit set for month " << month << " was set to 0.\n";
			deposit=0;
			balance=balance + deposit;
			totalDeposits=totalDeposits+deposit;
		
			
			
			
		cout << "Now enter the amount of money withdrawn for month " << month << "\n";
		cin >> withdrawl;
		if (withdrawl>=0 && withdrawl<balance)
		{
			balance=balance-withdrawl;
			totalWithdrawl = totalWithdrawl +withdrawl;
		}
		else
			cout << "Withdrawl amount entered is either less than 0 or greater than balance, therefore withdrawl for month " << month << " was set to 0.\n";
			withdrawl=0;
			balance=balance-withdrawl;
			totalWithdrawl = totalWithdrawl +withdrawl;
	}
	
	
	
	
	
	
	
	
	
	
	//Display Results
	cout << setprecision(2);
	cout << fixed;
	cout << "\n";
	cout << "Starting balance at the beginning of the three-month period is $" << startBalance<< "\n";
	cout << "Total deposits made during the three months was $" << totalDeposits<< "\n";
	cout << "Total withdrawals made during the three months was $" << totalWithdrawl<< "\n";
	cout << "Final balance at the end of the three month period is $" << balance<< "\n";
	cout << "\n";

	return 0;

}