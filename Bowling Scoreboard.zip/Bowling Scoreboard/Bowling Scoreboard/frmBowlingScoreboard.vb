﻿'Program Name:  Fitness Challenge
'Author:        Justin Nguyen
'Date:          October 30th, 2015
'Purpose:       The Bowling Scoreboard program enters the score
'               of the player. It displays each score, running
'               total, and final total.

Option Strict On

Public Class frmBowlingScoreboard


    Private Sub btnEnterFrame_Click(sender As Object, e As EventArgs) Handles btnEnterFrame.Click
        'The Enter Frame Button accepts and displays up to 10 bowing scores
        'and then calculates and displays the total

        'Declare and initialize variables

        Dim strScore As String
        Dim intScore As Integer
        Dim intTotal As Integer
        Dim strInputMessage As String = "Enter your bowling score for frame #"
        Dim strInputHeading As String = "Bowling Score"
        Dim strNormalMessage As String = "Enter your bowling score for frame #"
        Dim strNonNumericError As String = "Error-Enter a number for the bowling score of frame #"
        Dim strNegativeError As String = "Error - Enter a positive score for bowling frame #"

        'Declare Initial Loop Variables
        Dim strCancelClicked As String = " "
        Dim intMaxNumberOfEntries As Integer = 10
        Dim intNumberOfEntries As Integer = 1

        'This loop allows the user to enter the frame score of up to 10 team members.
        'The loop terminates when the user has entered 10 scores values or the user
        'taps or clicks the cancel button or the close button in the input box

        strScore = InputBox(strInputMessage & intNumberOfEntries, strInputHeading, " ")

        Do Until intNumberOfEntries > intMaxNumberOfEntries Or strScore = strCancelClicked
            If IsNumeric(strScore) Then
                intScore = Convert.ToInt32(strScore)
                If intScore > 0 Then
                    intTotal = intTotal + intScore
                    lstFrameScore.Items.Add("Frame Score " & intScore & " Total Score " & intTotal)
                    intNumberOfEntries += 1
                    strInputMessage = strNormalMessage
                Else
                    strInputMessage = strNegativeError
                End If
            Else
                strInputMessage = strNonNumericError
            End If

            If intNumberOfEntries <= intMaxNumberOfEntries Then
                strScore = InputBox(strInputMessage & intNumberOfEntries, strInputHeading, " ")
            End If
        Loop

        'Displays total score
        If intNumberOfEntries > 1 Then
            lblTotalDisplay.Visible = True
            lblTotalDisplay.Text = "Final game score is " & intTotal.ToString
        Else
            MsgBox("No Score Value Entered")
        End If

        'Disables the enter score button
        btnEnterFrame.Enabled = False


    End Sub

    Private Sub mnuClear_Click(sender As Object, e As EventArgs) Handles mnuClear.Click
        'The mnuClear click event clears the listbox object and hides
        'the total score label. It also enables the enter score button

        lstFrameScore.Items.Clear()
        lblTotalDisplay.Visible = False
        btnEnterFrame.Enabled = True
    End Sub

    Private Sub mnuExit_Click(sender As Object, e As EventArgs) Handles mnuExit.Click
        'The mnuExit click event closes the window and exits the application

        Close()
    End Sub
End Class
