﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBowlingScoreboard
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblHeading = New System.Windows.Forms.Label()
        Me.lblSubHeading = New System.Windows.Forms.Label()
        Me.picBowling = New System.Windows.Forms.PictureBox()
        Me.btnEnterFrame = New System.Windows.Forms.Button()
        Me.lstFrameScore = New System.Windows.Forms.ListBox()
        Me.lblTotalDisplay = New System.Windows.Forms.Label()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.mnuFile = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuClear = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuExit = New System.Windows.Forms.ToolStripMenuItem()
        CType(Me.picBowling, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblHeading
        '
        Me.lblHeading.AutoSize = True
        Me.lblHeading.Font = New System.Drawing.Font("Palatino Linotype", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHeading.Location = New System.Drawing.Point(100, 24)
        Me.lblHeading.Name = "lblHeading"
        Me.lblHeading.Size = New System.Drawing.Size(234, 26)
        Me.lblHeading.TabIndex = 0
        Me.lblHeading.Text = "Frame-by-Frame Scoring"
        '
        'lblSubHeading
        '
        Me.lblSubHeading.AutoSize = True
        Me.lblSubHeading.Font = New System.Drawing.Font("Palatino Linotype", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSubHeading.Location = New System.Drawing.Point(146, 50)
        Me.lblSubHeading.Name = "lblSubHeading"
        Me.lblSubHeading.Size = New System.Drawing.Size(143, 20)
        Me.lblSubHeading.TabIndex = 1
        Me.lblSubHeading.Text = "Bowling Scoreboard"
        '
        'picBowling
        '
        Me.picBowling.Location = New System.Drawing.Point(117, 73)
        Me.picBowling.Name = "picBowling"
        Me.picBowling.Size = New System.Drawing.Size(201, 174)
        Me.picBowling.TabIndex = 2
        Me.picBowling.TabStop = False
        '
        'btnEnterFrame
        '
        Me.btnEnterFrame.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnEnterFrame.Font = New System.Drawing.Font("Palatino Linotype", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEnterFrame.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.btnEnterFrame.Location = New System.Drawing.Point(143, 253)
        Me.btnEnterFrame.Name = "btnEnterFrame"
        Me.btnEnterFrame.Size = New System.Drawing.Size(149, 32)
        Me.btnEnterFrame.TabIndex = 3
        Me.btnEnterFrame.Text = "Enter Each Frame"
        Me.btnEnterFrame.UseVisualStyleBackColor = False
        '
        'lstFrameScore
        '
        Me.lstFrameScore.Font = New System.Drawing.Font("Palatino Linotype", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstFrameScore.FormattingEnabled = True
        Me.lstFrameScore.ItemHeight = 20
        Me.lstFrameScore.Location = New System.Drawing.Point(95, 288)
        Me.lstFrameScore.Name = "lstFrameScore"
        Me.lstFrameScore.Size = New System.Drawing.Size(244, 244)
        Me.lstFrameScore.TabIndex = 4
        '
        'lblTotalDisplay
        '
        Me.lblTotalDisplay.AutoSize = True
        Me.lblTotalDisplay.Font = New System.Drawing.Font("Palatino Linotype", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotalDisplay.Location = New System.Drawing.Point(132, 532)
        Me.lblTotalDisplay.Name = "lblTotalDisplay"
        Me.lblTotalDisplay.Size = New System.Drawing.Size(171, 21)
        Me.lblTotalDisplay.TabIndex = 5
        Me.lblTotalDisplay.Text = "Final game score is 193"
        Me.lblTotalDisplay.Visible = False
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFile})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(434, 24)
        Me.MenuStrip1.TabIndex = 6
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'mnuFile
        '
        Me.mnuFile.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuClear, Me.mnuExit})
        Me.mnuFile.Name = "mnuFile"
        Me.mnuFile.Size = New System.Drawing.Size(37, 20)
        Me.mnuFile.Text = "File"
        '
        'mnuClear
        '
        Me.mnuClear.Name = "mnuClear"
        Me.mnuClear.Size = New System.Drawing.Size(152, 22)
        Me.mnuClear.Text = "Clear"
        '
        'mnuExit
        '
        Me.mnuExit.Name = "mnuExit"
        Me.mnuExit.Size = New System.Drawing.Size(152, 22)
        Me.mnuExit.Text = "Exit"
        '
        'frmBowlingScoreboard
        '
        Me.AcceptButton = Me.btnEnterFrame
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(434, 562)
        Me.Controls.Add(Me.lblTotalDisplay)
        Me.Controls.Add(Me.lstFrameScore)
        Me.Controls.Add(Me.btnEnterFrame)
        Me.Controls.Add(Me.picBowling)
        Me.Controls.Add(Me.lblSubHeading)
        Me.Controls.Add(Me.lblHeading)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frmBowlingScoreboard"
        Me.Text = "Bowling Scoreboard"
        CType(Me.picBowling, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblHeading As System.Windows.Forms.Label
    Friend WithEvents lblSubHeading As System.Windows.Forms.Label
    Friend WithEvents picBowling As System.Windows.Forms.PictureBox
    Friend WithEvents btnEnterFrame As System.Windows.Forms.Button
    Friend WithEvents lstFrameScore As System.Windows.Forms.ListBox
    Friend WithEvents lblTotalDisplay As System.Windows.Forms.Label
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents mnuFile As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuClear As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuExit As System.Windows.Forms.ToolStripMenuItem

End Class
